import torch
import torch.nn as nn
import torchvision.models as models


class EncoderCNN(nn.Module):
    def __init__(self, embed_size):
        super(EncoderCNN, self).__init__()
        resnet = models.resnet50(pretrained=True)
        for param in resnet.parameters():
            param.requires_grad_(False)  # freeze the ResNet50 part of the encoder (for transfer learning)
        
        modules = list(resnet.children())[:-1]
        self.resnet = nn.Sequential(*modules)
        self.embed = nn.Linear(resnet.fc.in_features, embed_size)

    def forward(self, images):
        features = self.resnet(images)
        features = features.view(features.size(0), -1)
        features = self.embed(features)
        return features
    

class DecoderRNN(nn.Module):
    def __init__(self, embed_size, hidden_size, vocab_size, num_layers=1):
        super(DecoderRNN, self).__init__()        
        self.embedding = nn.Embedding(vocab_size, embed_size)
        # batch_first – If True, then the input and output tensors are provided as (batch, seq, feature)
        self.lstm = nn.LSTM(embed_size, hidden_size, num_layers, batch_first=True)
        self.linear = nn.Linear(hidden_size, vocab_size)
    
    def forward(self, features, captions):
        features = features.unsqueeze(1)
        captions_embed = self.embedding(captions[:, :-1])
        feature_captions = torch.cat([features, captions_embed], dim=1)
        hidden, _ = self.lstm(feature_captions)
        decoded = self.linear(hidden)
        return decoded

    def sample(self, inputs, states=None, max_len=20):
        " accepts pre-processed image tensor (inputs) and returns predicted sentence (list of tensor ids of length max_len) "
        assert inputs.dim() in [2, 3], "The number of dimensions of inputs must be either 2 or 3."
        if inputs.dim() == 2:
            inputs = inputs.unsqueeze(1)
        output = []
        for i in range(max_len):
            hidden, states = self.lstm(inputs, states)
            decoded = self.linear(hidden)
            word_idx = torch.argmax(decoded, dim=2)
            output.append(word_idx.item())
            inputs = self.embedding(word_idx)
        return output